## ----include=FALSE------------------------------------------------------------
rm(list = ls())
library(tidyverse)
library(patchwork)
library(uwb)


## ----include=FALSE------------------------------------------------------------
# Fake data to plot scales
cd = tibble(yvar = rep(1, 10),
            xvar = letters[1:10])

# Starting plots to be built upon
cplot = ggplot(cd, aes(xvar, yvar)) +
  geom_col(aes(fill = xvar)) +
  labs(y = "", x = "") +
  theme_void() +
  theme(legend.position = 'none')

cplot_short = ggplot(cd[1:5, ], aes(xvar, yvar)) +
  geom_col(aes(fill = xvar)) +
  labs(y = "", x = "") +
  theme_void() +
  theme(legend.position = 'none')


## ----echo=FALSE, warning=FALSE, results='hide'--------------------------------
cplot1 = cplot + scale_fill_uwb("quali") +
  labs(title = 'Qualitative scale "quali"')

cplot2 = cplot +
  scale_fill_uwb("faks") +
  labs(title = 'UWB faculties "faks"')

cplot3 = cplot_short +
  scale_fill_uwb("mono", n = 5) +
  labs(title = 'Blue monochromatic scale  "mono"')

cplot4 = cplot_short +
  scale_fill_uwb("monored", n = 5) +
  labs(title = 'Red monochromatic scale  "monored"')

cplot5 = cplot + scale_fill_uwb("long", n = 10) +
  labs(title = 'Long scale "long"')

cplot6 = cplot_short + scale_fill_uwb("bi", n = 5) + labs(title = 'Bipolar scale "bi"')

cplot1 / cplot2 / cplot3 / cplot4 / cplot5 / cplot6


## ----echo=TRUE, warning=FALSE, results='hide'---------------------------------
# Bar plot of a single categorical variable (uses the theme internally)
prep_single(example_data, fak) |>
  mutate(title = "Distribution by faculty") |>
  plot_bar()


## ----echo=TRUE, warning=FALSE, results='hide'---------------------------------
ex_long <- example_data |>
  count(fak, typ) |>
  group_by(fak) |>
  mutate(pct = 100 * n / sum(n)) |>
  ungroup()

ggplot(ex_long, aes(x = fak, y = pct, fill = typ)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.85, color = "white") +
  scale_fill_uwb("quali") +
  labs(x = "", y = "%", fill = "")


## ----echo=TRUE, warning=FALSE, results='hide'---------------------------------
ggplot(ex_long, aes(x = fak, y = pct, fill = typ)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.85, color = "white") +
  scale_fill_uwb("quali", add_na = TRUE) +
  labs(x = "", y = "%", fill = "")

