## ----include=FALSE------------------------------------------------------------
rm(list = ls())
library(tidyverse)
library(uwb)


## -----------------------------------------------------------------------------
glimpse(example_data)


## -----------------------------------------------------------------------------
prep_single(example_data, fak)


## -----------------------------------------------------------------------------
prep_single(example_data, fak, order = TRUE)


## ----warning=FALSE------------------------------------------------------------
prep_single(example_data, fak) |>
  plot_bar()


## -----------------------------------------------------------------------------
prep_gr(example_data, typ, fak)


## -----------------------------------------------------------------------------
prep_gr(example_data, typ, fak, add_total = TRUE)


## ----warning=FALSE------------------------------------------------------------
prep_gr(example_data, typ, fak, add_total = TRUE) |>
  plot_stack()


## -----------------------------------------------------------------------------
prep_gr2(example_data, typ, fak, pohlavi)


## -----------------------------------------------------------------------------
prep_mc(example_data, vars = c("mc1", "mc2", "mc3", "mc4", "mc5"), chosen = 1)


## ----warning=FALSE------------------------------------------------------------
prep_mc(example_data, vars = c("mc1", "mc2", "mc3", "mc4", "mc5"),
        chosen = 1) |>
  plot_bar()


## -----------------------------------------------------------------------------
prep_mc_gr(example_data,
           vars = c("mc1", "mc2", "mc3", "mc4", "mc5"),
           grvar = fak, chosen = 1)


## -----------------------------------------------------------------------------
prep_bat(example_data, vars = c("bat1", "bat2", "bat3", "bat4", "bat5"))


## ----warning=FALSE------------------------------------------------------------
prep_bat(example_data, vars = c("bat1", "bat2", "bat3", "bat4", "bat5")) |>
  plot_stack()


## -----------------------------------------------------------------------------
prep_bat_gr(example_data,
            vars = c("bat1", "bat2", "bat3", "bat4", "bat5"),
            grvar = pohlavi)


## -----------------------------------------------------------------------------
mean_bat(example_data, vars = c("num1", "num2", "num3", "num4", "num5"))


## ----warning=FALSE------------------------------------------------------------
mean_bat(example_data, vars = c("num1", "num2", "num3", "num4", "num5")) |>
  plot_lolli()


## -----------------------------------------------------------------------------
mean_bat_gr(example_data,
            vars = c("num1", "num2", "num3", "num4", "num5"),
            grvar = fak)


## -----------------------------------------------------------------------------
mean_bat_gr(example_data,
            vars = c("num1", "num2", "num3", "num4", "num5"),
            grvar = fak, add_total = TRUE)


## -----------------------------------------------------------------------------
mean_bat_gr2(example_data,
             vars = c("num1", "num2", "num3", "num4", "num5"),
             grvar = fak, grvar2 = pohlavi)


## -----------------------------------------------------------------------------
tibble(yvar = c(5, 42, 0.3, 88)) |>
  generate_textlabs()


## -----------------------------------------------------------------------------
tibble(name = c("num1", "num2")) |>
  impute_labs()


## -----------------------------------------------------------------------------
tibble(
  xvar_df = c("A very long faculty name that needs wrapping", "Short"),
  nsize = c(15, 320)
) |>
  polish_var(chrnum = 20)

